/* Tee 95 — storefront behaviour. No dependencies.
   window.W95 (money format + routes) is set in layout/theme.liquid. */
(function () {
  'use strict';

  var W95 = (window.W95 = window.W95 || {});
  W95.routes = W95.routes || { root: '/', cart: '/cart', cartAdd: '/cart/add.js' };

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var $$ = function (sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); };

  /* ---- money ----------------------------------------------------------- */
  function formatNumber(cents, decimals, thousands, point) {
    var parts = (cents / 100).toFixed(decimals).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousands);
    return parts.join(point);
  }
  W95.money = function (cents) {
    var format = W95.moneyFormat || '${{amount}}';
    return format.replace(/\{\{\s*(\w+)\s*\}\}/, function (match, key) {
      switch (key) {
        case 'amount_no_decimals': return formatNumber(cents, 0, ',', '.');
        case 'amount_with_comma_separator': return formatNumber(cents, 2, '.', ',');
        case 'amount_no_decimals_with_comma_separator': return formatNumber(cents, 0, '.', ',');
        case 'amount_with_apostrophe_separator': return formatNumber(cents, 2, "'", '.');
        case 'amount_no_decimals_with_space_separator': return formatNumber(cents, 0, ' ', '.');
        case 'amount_with_space_separator': return formatNumber(cents, 2, ' ', ',');
        default: return formatNumber(cents, 2, ',', '.');
      }
    });
  };

  /* ---- tray clock ------------------------------------------------------ */
  function tick() {
    var now = new Date();
    var text = now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    $$('[data-w95-clock]').forEach(function (el) { el.textContent = text; });
  }
  tick();
  setInterval(tick, 15000);

  /* ---- Start menu ------------------------------------------------------ */
  var startBtn = $('[data-w95-start]');
  var startMenu = $('[data-w95-startmenu]');
  function setStart(open) {
    if (!startBtn || !startMenu) return;
    startMenu.hidden = !open;
    startBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) { var first = $('a, button', startMenu); if (first) first.focus(); }
  }
  if (startBtn && startMenu) {
    startBtn.addEventListener('click', function () { setStart(startMenu.hidden); });
    document.addEventListener('click', function (e) {
      if (!startMenu.hidden && !startMenu.contains(e.target) && !startBtn.contains(e.target)) setStart(false);
    });
  }

  /* ---- windows: open, close, drag ------------------------------------- */
  var zTop = 20;
  function raise(win) { win.style.zIndex = String(++zTop); }

  document.addEventListener('click', function (e) {
    var closer = e.target.closest('[data-w95-close]');
    if (closer) {
      var win = closer.closest('[data-w95-window]');
      if (win) { win.hidden = true; e.preventDefault(); }
      return;
    }
    var opener = e.target.closest('[data-w95-open]');
    if (opener) {
      var target = document.getElementById(opener.getAttribute('data-w95-open'));
      if (target) {
        target.hidden = false;
        raise(target);
        var focusable = $('[data-w95-close]', target);
        if (focusable) focusable.focus();
      }
    }
  });

  var canDrag = window.matchMedia('(min-width: 1100px) and (pointer: fine)');
  $$('[data-w95-drag]').forEach(function (win) {
    var bar = $('.w95-titlebar', win);
    if (!bar) return;
    var x = 0, y = 0, startX = 0, startY = 0, dragging = false;
    bar.addEventListener('pointerdown', function (e) {
      if (!canDrag.matches || e.target.closest('.w95-titlebar__controls')) return;
      dragging = true; startX = e.clientX - x; startY = e.clientY - y;
      raise(win);
      bar.setPointerCapture(e.pointerId);
    });
    bar.addEventListener('pointermove', function (e) {
      if (!dragging) return;
      x = e.clientX - startX; y = e.clientY - startY;
      win.style.transform = 'translate(' + x + 'px,' + y + 'px)';
    });
    ['pointerup', 'pointercancel'].forEach(function (type) {
      bar.addEventListener(type, function () { dragging = false; });
    });
    win.addEventListener('pointerdown', function () { raise(win); });
  });

  /* ---- message box ----------------------------------------------------- */
  var modal = $('[data-w95-modal]');
  var lastFocus = null;
  W95.message = function (opts) {
    if (!modal) { window.alert(opts.text); return; }
    lastFocus = document.activeElement;
    $('[data-w95-modal-title]', modal).textContent = opts.title || '';
    $('[data-w95-modal-text]', modal).textContent = opts.text || '';
    var icon = $('[data-w95-modal-icon]', modal);
    icon.src = modal.getAttribute('data-icon-' + (opts.icon || 'info')) || icon.src;
    var actions = $('[data-w95-modal-actions]', modal);
    actions.innerHTML = '';
    (opts.buttons || [{ label: 'OK' }]).forEach(function (b, i) {
      var el = document.createElement(b.href ? 'a' : 'button');
      el.className = 'w95-btn' + (i === 0 ? ' w95-btn--default' : '');
      el.textContent = b.label;
      if (b.href) el.href = b.href; else { el.type = 'button'; el.addEventListener('click', closeMessage); }
      actions.appendChild(el);
    });
    modal.hidden = false;
    var first = $('.w95-btn', actions);
    if (first) first.focus();
  };
  function closeMessage() {
    if (!modal || modal.hidden) return;
    modal.hidden = true;
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  if (modal) {
    modal.addEventListener('click', function (e) {
      if (e.target === modal || e.target.closest('[data-w95-modal-close]')) closeMessage();
    });
  }
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (modal && !modal.hidden) { closeMessage(); return; }
    if (startMenu && !startMenu.hidden) { setStart(false); startBtn.focus(); }
  });

  /* ---- collection sort ------------------------------------------------- */
  $$('[data-w95-sort]').forEach(function (select) {
    select.addEventListener('change', function () {
      var url = new URL(window.location.href);
      url.searchParams.set('sort_by', select.value);
      url.searchParams.delete('page');
      window.location.assign(url.toString());
    });
  });

  /* ---- product page ---------------------------------------------------- */
  function setCartCount(count) {
    $$('[data-w95-cart-count]').forEach(function (el) { el.textContent = String(count); });
  }

  $$('[data-w95-product]').forEach(function (root) {
    var form = $('form.w95-product-form', root);
    var idInput = form && $('input[name="id"]', form);
    var addBtn = $('[data-w95-add]', root);
    var priceEl = $('[data-w95-price]', root);
    var mainImage = $('[data-w95-main-image]', root);
    var variants = [];
    try { variants = JSON.parse($('[data-w95-variants]', root).textContent); } catch (err) { variants = []; }

    function showImage(src, alt) {
      if (!mainImage || !src) return;
      mainImage.removeAttribute('srcset');
      mainImage.src = src;
      if (alt != null) mainImage.alt = alt;
    }

    // thumbnails
    $$('[data-w95-thumb]', root).forEach(function (thumb) {
      thumb.addEventListener('click', function () {
        showImage(thumb.getAttribute('data-src'), thumb.getAttribute('data-alt'));
        $$('[data-w95-thumb]', root).forEach(function (t) { t.removeAttribute('aria-current'); });
        thumb.setAttribute('aria-current', 'true');
      });
    });

    // option buttons -> variant
    function selectedOptions() {
      return $$('[data-w95-option]', root).map(function (group) {
        var checked = $('input:checked', group);
        return checked ? checked.value : null;
      });
    }
    function renderVariant(variant) {
      if (!addBtn) return;
      if (!variant) {
        addBtn.disabled = true; addBtn.textContent = addBtn.getAttribute('data-label-unavailable') || 'Unavailable';
        return;
      }
      if (idInput) idInput.value = variant.id;
      addBtn.disabled = !variant.available;
      addBtn.textContent = variant.available
        ? (addBtn.getAttribute('data-label-add') || 'Add to cart')
        : (addBtn.getAttribute('data-label-soldout') || 'Sold out');
      if (priceEl) {
        var onSale = variant.compare_at_price && variant.compare_at_price > variant.price;
        priceEl.innerHTML =
          '<span class="w95-price' + (onSale ? ' w95-price--sale' : '') + '">' +
          (onSale ? '<s>' + W95.money(variant.compare_at_price) + '</s>' : '') +
          W95.money(variant.price) + '</span>' +
          (variant.available ? '' : '<span class="w95-badge">Sold out</span>');
      }
      if (variant.featured_image && variant.featured_image.src) {
        showImage(variant.featured_image.src, variant.featured_image.alt || '');
      }
      if (window.history && window.history.replaceState) {
        var url = new URL(window.location.href);
        url.searchParams.set('variant', variant.id);
        window.history.replaceState({}, '', url.toString());
      }
    }
    $$('[data-w95-option] input', root).forEach(function (input) {
      input.addEventListener('change', function () {
        var chosen = selectedOptions();
        var match = variants.filter(function (v) {
          return v.options.every(function (value, i) { return value === chosen[i]; });
        })[0];
        renderVariant(match || null);
      });
    });

    // add to cart without leaving the page
    if (form && window.fetch && window.FormData) {
      form.addEventListener('submit', function (e) {
        if (e.submitter && e.submitter.name && e.submitter.name !== 'add') return; // dynamic checkout etc.
        e.preventDefault();
        if (addBtn) addBtn.disabled = true;
        fetch(W95.routes.cartAdd, {
          method: 'POST',
          headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
          body: new FormData(form)
        })
          .then(function (res) { return res.json().then(function (data) { return { ok: res.ok, data: data }; }); })
          .then(function (res) {
            if (addBtn) addBtn.disabled = false;
            if (!res.ok) {
              W95.message({ title: 'Cart', icon: 'error', text: res.data.description || res.data.message || 'That item could not be added to your cart.' });
              return;
            }
            var title = res.data.product_title || 'Item';
            W95.message({
              title: 'Cart', icon: 'info',
              text: title + ' was added to your cart.',
              buttons: [{ label: 'View cart', href: W95.routes.cart }, { label: 'Keep shopping' }]
            });
            return fetch(W95.routes.cart + '.js', { headers: { Accept: 'application/json' } })
              .then(function (r) { return r.json(); })
              .then(function (cart) { setCartCount(cart.item_count); });
          })
          .catch(function () { form.submit(); }); // network problem: fall back to a normal form post
      });
    }
  });

  /* ---- 404 blue screen: any key returns to the desktop ------------------ */
  var bsod = $('[data-w95-bsod]');
  if (bsod) {
    document.addEventListener('keydown', function (e) {
      if (bsod.offsetParent === null) return; // not on screen
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (['Tab', 'Shift', 'Escape'].indexOf(e.key) !== -1) return;
      if (e.target.closest && e.target.closest('input, textarea, select, a, button, [data-w95-startmenu]')) return;
      window.location.assign(bsod.getAttribute('data-home') || W95.routes.root);
    });
  }
})();
